import traci
import logging
from simlib import flatten

class IntersectionController():

    def __init__(self, intersection, zip=True):
        lanes = traci.trafficlight.getControlledLanes(intersection)
        self.lanesServed = set(lanes)
        self.name = intersection
        self.platoons = []
        self.platoonsZipped = set()
        self.platoonZips = []
        self.zip = zip

    def addPlatoon(self, platoon):
       
        self.platoons.append(platoon)
        if self.zip:
            platoon.addControlledLanes(self.lanesServed)

    def calculateNewReservedTime(self, pv, reservedTime):
        
        if reservedTime == 0:
            lenThruJunc = self._getLanePosition(pv) + pv.getLength()
        else:
            lenThruJunc = pv.getLength() * 2 if self.zip else 1
        return (0.5 if self.zip else 1.5) + reservedTime + (lenThruJunc / (pv.getSpeed() or 1))

    def _eligibleZippings(self, platoon):
        if len(self.platoonZips) >= 1:
            z = self.platoonZips[-1]
            if platoon.getLanePositionFromFront() - z[-1].getLanePositionFromFront() < 10 and platoon.getLanePositionFromFront() - z[-1].getLanePositionFromFront() > 0:
                return z

    def removeIrreleventPlatoons(self):
       
        for p in self.platoons:
            if not p.isActive() or all([l not in self.lanesServed for l in p.getLanesOfAllVehicles()]):
                self.removePlatoon(p)
                if self.zip:
                    for zip in self.platoonZips:
                        for platoon in zip:
                            if platoon == p:
                                zip.remove(platoon)
                        if not zip:
                            self.platoonZips.remove(zip)

    def findAndAddReleventPlatoons(self, platoons):
        
        def platoonPosition(platoon):
            return self._getLanePosition(platoon)

        platoons.sort(key=platoonPosition)
        for p in platoons:
            if p.getLane() in self.lanesServed and p not in self.platoons:
                self.addPlatoon(p)

    def getVehicleZipOrderThroughJunc(self):
        
        def distSort(elem):
            return elem.getLanePositionFromFront()

        if self.zip:
            prelimList = flatten([self._zipPlatoons(z) for z in self.platoonZips])
            prelimList.sort(key=distSort)
            return prelimList

    def _generatePlatoonZips(self):
        
        for p in self.platoons:
            if p not in self.platoonsZipped:
                eligibleZipping = self._eligibleZippings(p)
                if eligibleZipping:
                    eligibleZipping.append(p)
                else:
                    self.platoonZips.append([p])
                self.platoonsZipped.add(p)

    def _getLanePosition(self, v):
        
        if v.isActive():
            if v.getLane() in self.lanesServed:
                return v.getLanePositionFromFront()
        return 1000

    def getNewSpeed(self, pv, reservedTime):
       
        distanceToTravel = self._getLanePosition(pv)
        currentSpeed = pv.getSpeed()
        # If we are in the last 20 metres, we assume no more vehicles will join the platoon
        # and then set the speed to be constant. This is because if we did not speed tends
        # towards 0 (as the distance we give is to the junction and not to the end of the platoon's
        # route.
        if distanceToTravel > 20:
            pv.setSpeedMode(23)
            speed = distanceToTravel / (reservedTime or 1)
            speed = max([speed, 0.5])
            if speed >= currentSpeed:
                speed = pv.getMaxSpeed()
        elif currentSpeed == 0:
            speed = pv.getMaxSpeed()
        else:
            return pv.getMaxSpeed()
        if reservedTime == 0:
            return pv.getMaxSpeed()
        return speed

    def removePlatoon(self, platoon):
       
        self.platoons.remove(platoon)
        # Resume normal speed behaviour
        platoon.removeTargetSpeed()
        platoon.setSpeedMode(31)
        if self.zip:
            platoon.removeControlledLanes(self.lanesServed)

    def update(self):
        
        reservedTime = 0
        if self.zip:
            self._generatePlatoonZips()
            for v in self.getVehicleZipOrderThroughJunc():
                if v.isActive() and v.getLane() in self.lanesServed:
                    speed = self.getNewSpeed(v, reservedTime)
                    v.setSpeed(speed)
                    reservedTime = self.calculateNewReservedTime(v, reservedTime)
        else:
            for p in self.platoons:
                # Update the speeds of the platoon if it has not passed the junction
                if p.getLane() in self.lanesServed:
                    speed = self.getNewSpeed(p, reservedTime)
                    if speed == -1:
                        p.removeTargetSpeed()
                    else:
                        p.setTargetSpeed(speed)
                    reservedTime = self.calculateNewReservedTime(p, reservedTime)
        self._logIntersectionStatus(reservedTime)

    def _logIntersectionStatus(self, reservation=None):
        
        if self.platoons:
            logging.info("------------%s Information------------", self.name)
            if self.zip:
                for v in self.getVehicleZipOrderThroughJunc():
                    if v.isActive():
                        setSpeed = v._previouslySetValues['setSpeed'] if 'setSpeed' in v._previouslySetValues else "None"
                        logging.info("Vehicle: %s, Target: %s, Current: %s", v.getName(), setSpeed, v.getSpeed())
                logging.info("------------Platoon Zips------------")
                for zip in self.platoonZips:
                    logging.info("Zip: %s", [p.getID() for p in zip])
            else:
                for p in self.platoons:
                    logging.info("Platoon: %s, Target: %s, Current: %s ", p.getID(), p.getTargetSpeed(), p.getSpeed())
            if reservation:
                logging.info("Total time reserved: %s", reservation)

    def _zipPlatoons(self, platoons):
       
        ret = []
        iterations = max([len(p.getAllVehicles()) for p in platoons])
        for i in range(0, iterations):
            for p in platoons:
                if len(p.getAllVehicles()) > i:
                    if p.getAllVehicles()[i].getLane() in self.lanesServed:
                        ret.append(p.getAllVehicles()[i])
        return ret