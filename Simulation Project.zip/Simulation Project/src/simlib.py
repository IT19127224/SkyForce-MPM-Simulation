import logging
import traci
from sumolib import checkBinary

def flatten(l):
     return [item for sublist in l for item in sublist]

def setUpSimulation(configFile, trafficScale = 1, outputFileLocation="output/additional.xml"):
    sumoBinary = checkBinary("sumo-gui")

   
    logging.basicConfig(format='%(asctime)s %(message)s')
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)

    
    traci.start([sumoBinary, "-c", configFile, "--step-length", "0.1", "--collision.action", "none", "--start",
                 "--additional-files", outputFileLocation, "--duration-log.statistics", "--scale", str(trafficScale)])